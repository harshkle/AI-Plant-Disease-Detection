
# 🌿 Plant Disease Detection - Fixed Google Colab Project

# CELL 1: Install libraries
!pip -q install kaggle gradio tensorflow pillow numpy

# CELL 2: Upload kaggle.json
from google.colab import files
uploaded = files.upload()
print("Uploaded files:", uploaded.keys())

# CELL 3: Setup Kaggle API
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/kaggle.json
!chmod 600 ~/.kaggle/kaggle.json
print("Kaggle setup completed.")

# CELL 4: Test Kaggle connection
!kaggle datasets list -s "new plant diseases dataset" | head

# CELL 5: Download dataset
!rm -rf /content/plant_dataset
!mkdir -p /content/plant_dataset
!kaggle datasets download -d vipoooool/new-plant-diseases-dataset -p /content/plant_dataset --unzip
print("Dataset download command finished.")

# CELL 6: Check dataset files
!ls -la /content/plant_dataset

# CELL 7: Automatically find train and valid folders
from pathlib import Path
import os

DATASET_ROOT = Path("/content/plant_dataset")
train_dir = None
valid_dir = None

for root, dirs, files in os.walk(DATASET_ROOT):
    lower_dirs = [d.lower() for d in dirs]
    if "train" in lower_dirs and ("valid" in lower_dirs or "validation" in lower_dirs):
        root_path = Path(root)
        train_dir = root_path / dirs[lower_dirs.index("train")]
        if "valid" in lower_dirs:
            valid_dir = root_path / dirs[lower_dirs.index("valid")]
        else:
            valid_dir = root_path / dirs[lower_dirs.index("validation")]
        break

print("Train folder:", train_dir)
print("Valid folder:", valid_dir)
print("Train exists:", train_dir.exists() if train_dir else False)
print("Valid exists:", valid_dir.exists() if valid_dir else False)

if train_dir is None or valid_dir is None:
    print("Could not find train/valid folders. Folders found:")
    for root, dirs, files in os.walk(DATASET_ROOT):
        if dirs:
            print(root, "=>", dirs[:10])

# CELL 8: Load images
import tensorflow as tf

IMG_SIZE = (224, 224)
BATCH_SIZE = 32
SEED = 42

train_ds = tf.keras.utils.image_dataset_from_directory(
    train_dir,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    seed=SEED
)

valid_ds = tf.keras.utils.image_dataset_from_directory(
    valid_dir,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    seed=SEED
)

class_names = train_ds.class_names
num_classes = len(class_names)

print("Number of classes:", num_classes)
print("First 10 classes:", class_names[:10])

train_ds = train_ds.prefetch(tf.data.AUTOTUNE)
valid_ds = valid_ds.prefetch(tf.data.AUTOTUNE)

# CELL 9: Build model
data_augmentation = tf.keras.Sequential([
    tf.keras.layers.RandomFlip("horizontal"),
    tf.keras.layers.RandomRotation(0.1),
    tf.keras.layers.RandomZoom(0.1),
])

base_model = tf.keras.applications.MobileNetV2(
    input_shape=(224, 224, 3),
    include_top=False,
    weights="imagenet"
)

base_model.trainable = False

inputs = tf.keras.Input(shape=(224, 224, 3))
x = data_augmentation(inputs)
x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
x = base_model(x, training=False)
x = tf.keras.layers.GlobalAveragePooling2D()(x)
x = tf.keras.layers.Dropout(0.25)(x)
outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)

model = tf.keras.Model(inputs, outputs)

model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

model.summary()

# CELL 10: Train model
callbacks = [
    tf.keras.callbacks.ModelCheckpoint(
        "plant_disease_model.keras",
        save_best_only=True,
        monitor="val_accuracy",
        mode="max"
    ),
    tf.keras.callbacks.EarlyStopping(
        monitor="val_accuracy",
        patience=2,
        restore_best_weights=True
    )
]

history = model.fit(
    train_ds,
    validation_data=valid_ds,
    epochs=3,
    callbacks=callbacks
)

model.save("plant_disease_model.keras")
print("Model saved.")

# CELL 11: Save labels
import json

with open("class_names.json", "w") as f:
    json.dump(class_names, f)

print("class_names.json saved.")

# CELL 12: Care suggestions
CARE_TIPS = {
    "healthy": "The plant looks healthy. Maintain proper watering, sunlight, drainage, and remove dry leaves regularly.",
    "early_blight": "Remove infected leaves, avoid overhead watering, improve airflow, and use a recommended fungicide if needed.",
    "late_blight": "Remove infected parts quickly, avoid wet leaves, improve spacing, and use copper-based or recommended fungicide.",
    "powdery_mildew": "Improve air circulation, avoid overcrowding, remove affected leaves, and use neem/sulfur treatment if suitable.",
    "leaf_spot": "Remove infected leaves, avoid water splashing on leaves, clean tools, and use a suitable fungicide.",
    "rust": "Remove infected leaves, avoid overhead watering, improve sunlight and airflow, and use recommended fungicide.",
    "bacterial_spot": "Remove affected leaves, avoid touching wet plants, use disease-free seeds, and apply copper treatment if advised.",
    "mosaic_virus": "Remove infected plants, control aphids/whiteflies, disinfect tools, and avoid seeds from infected plants.",
    "scab": "Prune for airflow, remove fallen infected leaves, avoid overhead irrigation, and use preventive fungicide."
}

def get_care_tip(predicted_class):
    text = predicted_class.lower().replace("___", " ").replace("_", " ")
    for key, tip in CARE_TIPS.items():
        if key in text:
            return tip
    return "General care: isolate the plant, remove infected leaves, avoid wetting leaves, improve sunlight and airflow, and consult a local agriculture expert."

print("Care tips ready.")

# CELL 13: Prediction function
import numpy as np
from PIL import Image

model = tf.keras.models.load_model("plant_disease_model.keras")

def predict_image(image):
    if image is None:
        return "Please upload or capture a plant leaf image.", ""

    img = Image.fromarray(image).convert("RGB")
    img = img.resize(IMG_SIZE)

    arr = np.array(img)
    arr = np.expand_dims(arr, axis=0)

    preds = model.predict(arr, verbose=0)[0]
    idx = int(np.argmax(preds))
    confidence = float(preds[idx]) * 100

    predicted_class = class_names[idx]
    readable_name = predicted_class.replace("___", " - ").replace("_", " ")
    care = get_care_tip(predicted_class)

    result = f"Prediction: {readable_name}\nConfidence: {confidence:.2f}%"

    if confidence < 60:
        result += "\n\n⚠️ Confidence is low. Try a clearer leaf image with good lighting."

    return result, care

print("Prediction function ready.")

# CELL 14: Launch website
import gradio as gr

with gr.Blocks(theme=gr.themes.Soft(), title="Plant Disease Detection") as demo:
    gr.Markdown("""
    # 🌿 Plant Disease Detection
    Upload a plant leaf image or use your camera.
    The AI model will predict the disease and suggest simple care methods.
    """)

    image_input = gr.Image(
        sources=["upload", "webcam"],
        type="numpy",
        label="Upload Image or Use Camera"
    )

    predict_btn = gr.Button("Detect Disease", variant="primary")

    prediction_output = gr.Textbox(label="Disease Prediction", lines=4)
    care_output = gr.Textbox(label="Suggested Care", lines=5)

    predict_btn.click(
        fn=predict_image,
        inputs=image_input,
        outputs=[prediction_output, care_output]
    )

demo.launch(share=True)

# CELL 15: Optional download model files for VS Code
# from google.colab import files
# files.download("plant_disease_model.keras")
# files.download("class_names.json")
